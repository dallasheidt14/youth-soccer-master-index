# Youth Soccer Master Team Index (Multi-Source Scraper)

This repo builds a **Master Team Index** (state × age × gender) by scraping multiple public sources:
- GotSport
- Modular11
- AthleteOne

Outputs a unified CSV per state/age/gender under `data/master/{STATE}/{STATE}_{AGE}_{GENDER}.csv` with a stable internal `team_id`,
and cross-source `external_ids` for later game-history scraping and ranking (v53e).

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements.txt

# Example: Build AZ U11 Boys master index using all providers
python src/scraper/build_master_team_index.py --state AZ --age 11 --gender M
```
