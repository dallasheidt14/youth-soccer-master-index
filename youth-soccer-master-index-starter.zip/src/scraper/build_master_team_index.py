import argparse, pandas as pd
from pathlib import Path
from .providers import gotsport_scraper, modular11_scraper, athleteone_scraper
from .utils.normalizer import normalize_age, normalize_gender
from .utils.fuzzy_merge import merge_sources
from .utils.logger import get_logger

log = get_logger("orchestrator")

PROVIDERS = {
    "GotSport": gotsport_scraper,
    "Modular11": modular11_scraper,
    "AthleteOne": athleteone_scraper,
}

def _internal_team_id(state: str, age: str, gender: str, seq: int) -> str:
    return f"{state}_{normalize_age(age)}_{normalize_gender(gender)}_{seq:06d}"

def build_master_index(state: str, age: str, gender: str, providers=None) -> pd.DataFrame:
    providers = providers or list(PROVIDERS.keys())
    outdir = Path(f"data/master/{state}")
    outdir.mkdir(parents=True, exist_ok=True)
    outfile = outdir / f"{state}_{normalize_age(age)}_{normalize_gender(gender)}.csv"

    base = pd.read_csv(outfile) if outfile.exists() else pd.DataFrame(columns=[
        "team_id","team_name","club_name","state","gender","age_group",
        "source","external_id","url","scrape_date","external_ids","merged_key"
    ])

    aggregated = base.copy()
    for name in providers:
        log.info(f"Scraping provider: {name}")
        df = PROVIDERS[name].scrape_teams(age_group=age, gender=gender, state=state)
        if df is None or df.empty:
            log.warning(f"{name}: no data returned")
            continue
        for col in ["team_name","club_name","external_id","url","state","gender","age_group","source","merged_key","scrape_date"]:
            if col not in df.columns: df[col] = ""
        df["source"] = name
        aggregated = merge_sources(aggregated, df, threshold=90.0)

    if "team_id" not in aggregated.columns:
        aggregated["team_id"] = ""
    missing = aggregated["team_id"] == ""
    seq_start = (aggregated["team_id"] != "").sum() + 1
    seq = seq_start
    for idx in aggregated.index[missing]:
        aggregated.at[idx, "team_id"] = _internal_team_id(state, age, gender, seq)
        seq += 1

    keep_cols = ["team_id","team_name","club_name","state","gender","age_group","source","external_id","url","scrape_date","external_ids","merged_key"]
    aggregated = aggregated[keep_cols].sort_values(by=["club_name","team_name"]).reset_index(drop=True)
    aggregated.to_csv(outfile, index=False)
    log.info(f"✅ Saved registry: {outfile} ({len(aggregated)} rows)")
    return aggregated

def main():
    ap = argparse.ArgumentParser(description="Build Master Team Index")
    ap.add_argument("--state", required=True)
    ap.add_argument("--age", required=True)
    ap.add_argument("--gender", required=True)
    ap.add_argument("--providers", nargs="*", default=["GotSport","Modular11","AthleteOne"])
    args = ap.parse_args()
    build_master_index(args.state.upper(), args.age, args.gender, args.providers)

if __name__ == "__main__":
    main()
