from bs4 import BeautifulSoup
import pandas as pd, datetime as dt, json
from ..utils.zenrows_client import fetch_html
from ..utils.normalizer import canonical_key, normalize_age, normalize_gender

BASE_API = "https://system.gotsport.com/api/v1/team_ranking_data"

def _build_url(age_group: str, gender: str, page: int = 1):
    age_num = normalize_age(age_group).replace("U","")
    g = normalize_gender(gender).lower()  # 'm' or 'f'
    return (f"{BASE_API}?search%5Bcountry%5D=USA"
            f"&search%5Bage%5D={age_num}"
            f"&search%5Bgender%5D={g}"
            f"&search%5Bpage%5D={page}")

def scrape_teams(age_group: str, gender: str, state: str | None = None, max_pages: int = 40) -> pd.DataFrame:
    rows = []
    for page in range(1, max_pages+1):
        url = _build_url(age_group, gender, page)
        html = fetch_html(url)
        if not html:
            break
        try:
            data = json.loads(html)
        except Exception:
            try:
                start = html.find('{'); end = html.rfind('}') + 1
                data = json.loads(html[start:end])
            except Exception:
                break
        items = data.get("items") or data.get("data") or []
        if not items:
            break
        for it in items:
            team = it.get("name") or it.get("team_name") or ""
            club = it.get("club_name") or it.get("club") or ""
            tid  = it.get("team_id") or it.get("id") or ""
            st   = (it.get("state") or "").upper()
            if state and st and st != state.upper():
                continue
            url_team = f"https://system.gotsport.com/organizations/teams/{tid}" if tid else ""
            rows.append({
                "team_name": team,
                "club_name": club,
                "external_id": str(tid),
                "url": url_team,
                "state": st or (state or ""),
                "gender": normalize_gender(gender),
                "age_group": normalize_age(age_group),
                "source": "GotSport",
                "merged_key": canonical_key(team),
                "scrape_date": dt.date.today().isoformat(),
            })
    return pd.DataFrame(rows).drop_duplicates(subset=["external_id","merged_key"])
