import pandas as pd
from ..utils.normalizer import canonical_key, normalize_age, normalize_gender

def scrape_teams(age_group: str, gender: str, state: str | None = None) -> pd.DataFrame:
    # TODO: Implement Modular11 team list scraping.
    # Return empty DataFrame with required columns for now.
    cols = ["team_name","club_name","external_id","url","state","gender","age_group","source","merged_key","scrape_date"]
    return pd.DataFrame(columns=cols)
