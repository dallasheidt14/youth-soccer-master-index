from rapidfuzz import fuzz
import pandas as pd, json

def _parse_ext(x):
    if isinstance(x, dict): return x
    if not isinstance(x, str) or not x.strip(): return {}
    try:
        return json.loads(x)
    except Exception:
        return {}

def merge_sources(base_df: pd.DataFrame, new_df: pd.DataFrame, threshold: float = 90.0) -> pd.DataFrame:
    if base_df is None or base_df.empty:
        # initialize external_ids as JSON strings
        nd = new_df.copy()
        nd["external_ids"] = nd.apply(lambda r: json.dumps({r["source"]: str(r.get("external_id") or "")}, ensure_ascii=False), axis=1)
        return nd

    base = base_df.copy().reset_index(drop=True)
    new  = new_df.copy().reset_index(drop=True)

    base["external_ids"] = base.get("external_ids", "").apply(_parse_ext)
    new["external_ids"]  = new.get("external_ids", "").apply(_parse_ext)

    taken = set()
    for i, nrow in new.iterrows():
        nk = nrow["merged_key"]
        best_j, best_score = None, -1
        for j, brow in base.iterrows():
            if j in taken: continue
            score = fuzz.token_sort_ratio(nk, brow["merged_key"])
            if score > best_score:
                best_j, best_score = j, score
        if best_score >= threshold:
            ext = base.at[best_j, "external_ids"]
            ext[nrow["source"]] = str(nrow.get("external_id") or "")
            base.at[best_j, "external_ids"] = ext
            if len(str(nrow["team_name"])) > len(str(base.at[best_j, "team_name"])):
                base.at[best_j, "team_name"] = nrow["team_name"]
            taken.add(best_j)
        else:
            base = pd.concat([base, pd.DataFrame([nrow])], ignore_index=True)

    base["external_ids"] = base["external_ids"].apply(lambda d: json.dumps(d, ensure_ascii=False))
    base = base.drop_duplicates(subset=["merged_key"], keep="first")
    return base
