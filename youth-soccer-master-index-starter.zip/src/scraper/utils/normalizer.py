import re

def canonical_key(name: str) -> str:
    if not isinstance(name, str) or not name:
        return ""
    s = name.lower()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    s = re.sub(r"\b(fc|sc|soccer club|futbol club)\b", "", s)
    s = " ".join(s.split())
    return s.replace(" ", "_")

def normalize_gender(g: str) -> str:
    g = (g or "").strip().lower()
    if g.startswith("m") or g in {"boys","boy","male"}: return "M"
    if g.startswith("f") or g in {"girls","girl","female"}: return "F"
    return g.upper()[:1]

def normalize_age(age: str | int) -> str:
    s = str(age).upper().strip()
    if s.startswith("U"): return s
    return f"U{s}"
