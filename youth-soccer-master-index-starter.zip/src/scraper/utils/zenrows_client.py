import os, time, requests, random
from .logger import get_logger
log = get_logger("zenrows")

ZENROWS_KEY = os.getenv("ZENROWS_API_KEY")

def fetch_html(url: str, retries: int = 3, min_wait: float = 0.8, max_wait: float = 2.0) -> str | None:
    if not ZENROWS_KEY:
        log.warning("ZENROWS_API_KEY is not set; attempting direct fetch (may fail on JS/CF).")
        try:
            r = requests.get(url, timeout=60, headers={"User-Agent": "Mozilla/5.0"})
            if r.status_code == 200:
                return r.text
            log.error(f"Direct fetch failed: {r.status_code}")
            return None
        except Exception as e:
            log.error(f"Direct fetch error: {e}")
            return None

    endpoint = "https://api.zenrows.com/v1/"
    for attempt in range(1, retries+1):
        try:
            params = {"apikey": ZENROWS_KEY, "url": url, "js_render": "true", "premium_proxy": "true"}
            r = requests.get(endpoint, params=params, timeout=90)
            if r.status_code == 200 and len(r.text) > 500:
                return r.text
            log.warning(f"ZenRows bad response [{r.status_code}] len={len(r.text)} attempt={attempt}")
        except Exception as e:
            log.warning(f"ZenRows error attempt={attempt}: {e}")
        time.sleep(random.uniform(min_wait, max_wait))
    return None
