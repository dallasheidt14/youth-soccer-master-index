import logging, os

def get_logger(name: str = "scraper", level: str = None) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    log_level = (level or os.getenv("LOG_LEVEL") or "INFO").upper()
    logger.setLevel(getattr(logging, log_level, logging.INFO))
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    logger.addHandler(ch)
    return logger
